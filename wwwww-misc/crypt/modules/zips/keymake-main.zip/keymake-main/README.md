very nice keymaker. makes random or deterministic key based on a password. 
