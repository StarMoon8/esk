# Secure1- README   version 001

1) input file, output file, key file. 

2) care is made to make this compile on linux or windows. 

3)  make sure you have enough free ram to load the entire key in memory and the entire file in memory. 
	
4) this is simple by design.  one can easily feed the code to ai and zeroize memory or use memory mapping or chunk based processing or whatever 
   as needed. as is, this is made to be simple, highly reliable and used with proper amount of free ram. 



